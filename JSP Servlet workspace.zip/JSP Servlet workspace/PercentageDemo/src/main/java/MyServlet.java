import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet (urlPatterns = "/MyServlet")
public class MyServlet extends HttpServlet
{
		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
		{
			String username=req.getParameter("username");
			float subject1=Float.parseFloat(req.getParameter("Subject1"));
			float subject2=Float.parseFloat(req.getParameter("Subject2"));
			float subject3=Float.parseFloat(req.getParameter("Subject3"));
			
			float percentage=(subject1+subject2+subject3)/300*100;
			
			resp.setContentType("text/html");
			PrintWriter out=resp.getWriter();
			out.print("Welcome"+username+"<br>");
			out.print("Percentage" +percentage+"<br>");
			
			
			if (subject1>=50 && subject2>=50 && subject3>=50)
			{
				out.print("Pass"+"<br>");
			}
			else
			{
				out.print("Fail");

			}
		}
}
