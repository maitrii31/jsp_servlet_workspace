import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet (urlPatterns= "/LoginServlet")
public class LoginServlet extends HttpServlet
{
		@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
		{
			String uname=req.getParameter("username");
			String password=req.getParameter("password");
			
			PrintWriter pw=resp.getWriter();
			if (uname.equals("admin")&& password.equals("Pass@123"))
			{
				pw.print("Welcome Admin");
			} 
			else 
			{
				pw.print("Incorrect Username or Password");
			}
		}
}
