import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns= "/MyServlet")
public class MyServlet extends HttpServlet
{
		@Override
		protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
		{
			String fname=req.getParameter("first_name");
			String lname=req.getParameter("last_name");
			PrintWriter out= resp.getWriter();
			out.print("Welcome "+fname+ "" +lname);
		}
}
